# Useful Bash Scripts

A repository of useful bash script commands
