#!/bin/bash
#
# Set up line number in vim. Tested in Ubuntu and Mac. 
#
# Method of use:
# source setup_vim.sh
#


echo "
set number
" >> ~/.vimrc

echo ".vimrc updated"
